import React from 'react';

const Skill = () => {
    return (
        <div id='skill' className='mx-4 md:mx-16 bg-slate-50 shadow-lg px-4 py-12 md:p-12 '>
            <h2 className='text-3xl font-bold text-gray-800 text-center mb-12'>Skill</h2>
            <div>
                <h3 className='text-2xl font-bold my-3 text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-pink-600 hover:to-purple-600'>Frontend:</h3>
                <div>
                    
                </div>
            </div>
        </div>
    );
};

export default Skill;